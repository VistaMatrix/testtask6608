@extends('admin.layouts.master')

@section('content')

    <div class="row">
        <div class="col-sm-10 col-sm-offset-2">
            <h1>Update Category</h1>

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        {!! implode('', $errors->all('
                        <li class="error">:message</li>
                        ')) !!}
                    </ul>
                </div>
            @endif
        </div>
    </div>

    {!! Form::open(['files' => true,'route' => ['updateblog', $Blogs->id], 'class' => 'form-horizontal', 'method' => 'PATCH']) !!}

    <div class="form-group">
        {!! Form::label('heading', trans('heading'), ['class'=>'col-sm-2 control-label']) !!}
        <div class="col-sm-10">
            {!! Form::text('heading', old('heading', $Blogs->heading), ['class'=>'form-control', 'placeholder'=> trans('heading')]) !!}
        </div>
    </div>

    <div class="form-group">
        {!! Form::label('title', trans('title'), ['class'=>'col-sm-2 control-label']) !!}
        <div class="col-sm-10">
            {!! Form::text('title', old('title', $Blogs->title), ['class'=>'form-control', 'placeholder'=> trans('title')]) !!}
        </div>
    </div>

    <div class="form-group">
        {!! Form::label('content', trans('content'), ['class'=>'col-sm-2 control-label']) !!}
        <div class="col-sm-10">
            {!! Form::text('content', old('content', $Blogs->content), ['class'=>'form-control', 'placeholder'=> trans('content')]) !!}
        </div>
    </div>

    <div class="form-group">
        {!! Form::label('status', trans('status'), ['class'=>'col-sm-2 control-label']) !!}
        <div class="col-sm-10">
          <input type="checkbox" name="status" class="switch-input"  {{  ($Blogs->status == 1 ? ' checked' : '') }}/>
        </div>
    </div>

    <div class="col-xs-12 col-sm-12">
        <div class="form-group">
            <strong>banner_image</strong>
            {!! Form::file('banner_image', array('class' => 'form-control')) !!}
        </div>     
    </div>

    <div class="form-group">
        <div class="col-sm-10 col-sm-offset-2">
            {!! Form::submit(trans('quickadmin::admin.users-edit-btnupdate'), ['class' => 'btn btn-primary']) !!}
        </div>
    </div>

    {!! Form::close() !!}

@endsection


