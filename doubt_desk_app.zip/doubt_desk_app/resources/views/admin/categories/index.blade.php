@extends('admin.layouts.master')

@section('content')

    <p>{!! link_to_route('addcategory', trans('quickadmin::admin.users-index-add_new'), [], ['class' => 'btn btn-success']) !!}</p>

    @if($Categories->count() > 0)
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">Category List</div>
            </div>
            <div class="portlet-body">
                <table id="datatable" class="table table-striped table-hover table-responsive datatable">
                    <thead>
                    <tr>
                        <th>{{ trans('quickadmin::admin.users-index-name') }}</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>&nbsp;</th>
                    </tr>
                    </thead>

                    <tbody>
                    @foreach ($Categories as $Categorie)
                        <tr>
                            <td>{{ $Categorie->category_name }}</td>
                            <td>{{ $Categorie->category_description }}</td>
                            <td><img  style="border-radius: 50%;height: 50px;width: 80px;"  src="<?php echo asset("uploads/Category/{$Categorie->id}/photo/{$Categorie->category_photo}")?>"></td>
                            <td>{!! link_to_route('editcategory', trans('quickadmin::admin.users-index-edit'), [$Categorie->id], ['class' => 'btn btn-xs btn-info']) !!}
                            {!! Form::open(['style' => 'display: inline-block;', 'method' => 'DELETE', 'onsubmit' => 'return confirm(\'' . trans('quickadmin::admin.users-index-are_you_sure') . '\');',  'route' => array('deletecategory', $Categorie->id)]) !!}
                                {!! Form::submit(trans('quickadmin::admin.users-index-delete'), array('class' => 'btn btn-xs btn-danger')) !!}
                                {!! Form::close() !!}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>

    @else
        {{ trans('quickadmin::admin.users-index-no_entries_found') }}
    @endif

@endsection