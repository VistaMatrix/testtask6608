@extends('admin.layouts.master')

@section('content')
@foreach ($Blogs as $Blog)
<div class="card" style="width:250px">
  <img class="card-img-top" style="height: 100px;width: 100px;" src="<?php echo asset("uploads/Blog/{$Blog->id}/photo/{$Blog->banner_image}")?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">{{ $Blog->title }}</h4>
    <p class="card-text">{{ $Blog->content }}</p>
    <a href="#" class="btn btn-primary">Read More</a>
  </div>
</div>
@endforeach
@endsection