<?php $__env->startSection('content'); ?>

    <p><?php echo link_to_route('addsubcategory', trans('quickadmin::admin.users-index-add_new'), [], ['class' => 'btn btn-success']); ?></p>

    <?php if($subCategory->count() > 0): ?>
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">Sub Category List</div>
            </div>
            <div class="portlet-body">
                <table id="datatable" class="table table-striped table-hover table-responsive datatable">
                    <thead>
                    <tr>
                        <th><?php echo e(trans('quickadmin::admin.users-index-name')); ?></th>
                        <th>&nbsp;</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($subCategor->category_name); ?></td>
                            <td>
                               <?php echo link_to_route('editsubcategory', trans('quickadmin::admin.users-index-edit'), [$subCategor->id], ['class' => 'btn btn-xs btn-info']); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php else: ?>
        <?php echo e(trans('quickadmin::admin.users-index-no_entries_found')); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\investor_app\resources\views/admin/subcategory/index.blade.php ENDPATH**/ ?>