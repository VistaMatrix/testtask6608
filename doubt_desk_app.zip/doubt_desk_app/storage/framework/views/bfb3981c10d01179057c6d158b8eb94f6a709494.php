<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-10 col-sm-offset-2">
            <h1>Create Your blog</h1>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php echo implode('', $errors->all('
                        <li class="error">:message</li>
                        ')); ?>

                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php echo Form::open(['files' => true,'route' => 'saveblog', 'class' => 'form-horizontal']); ?>


    <div class="form-group">
        <?php echo Form::label('heading', trans('heading'), ['class'=>'col-sm-2 control-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::text('heading', old('heading'), ['class'=>'form-control', 'placeholder'=> trans('heading')]); ?>

        </div>
    </div>

    <div class="form-group">
        <?php echo Form::label('title', trans('title'), ['class'=>'col-sm-2 control-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::text('title', old('title'), ['class'=>'form-control', 'placeholder'=> trans('title')]); ?>

        </div>
    </div>

    <div class="form-group">
        <?php echo Form::label('content', trans('content'), ['class'=>'col-sm-2 control-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::text('content', old('content'), ['class'=>'form-control', 'placeholder'=> trans('content')]); ?>

        </div>
    </div>

    <div class="form-group">
        <?php echo Form::label('status', trans('status'), ['class'=>'col-sm-2 control-label']); ?>

        <div class="col-sm-10">
          <input type="checkbox" name="status" class="switch-input">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12">
        <div class="form-group">
            <strong>banner_image</strong>
            <?php echo Form::file('banner_image', array('class' => 'form-control')); ?>

        </div>     
    </div>

    <div class="form-group">
        <div class="col-sm-10 col-sm-offset-2">
            <?php echo Form::submit(trans('quickadmin::admin.users-create-btncreate'), ['class' => 'btn btn-primary']); ?>

        </div>
    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doubt_desk_app\resources\views/admin/blog/create.blade.php ENDPATH**/ ?>