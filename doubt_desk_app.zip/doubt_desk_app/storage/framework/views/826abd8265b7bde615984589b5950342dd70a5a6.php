<?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clearfix"></div>
<div class="page-container">

    <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-content-wrapper">
        <div class="page-content">

            <!-- <h3 class="page-title">
                <?php $list=explode("@",class_basename(app('request')->route()->getAction()['controller']))[0]; ?>
                <?php if($list==base64_decode('UXVpY2thZG1pbkNvbnRyb2xsZXI=')): ?>
                    Investor
                <?php else: ?>
                    <?php echo e(preg_replace('/([a-z0-9])?([A-Z])/','$1 $2',str_replace('Controller','',$list))); ?>


                <?php endif; ?>
            </h3> -->

            <div class="row">
                <div class="col-md-12">

                    <?php if(Session::has('message')): ?>
                        <div class="note note-info">
                            <p><?php echo e(Session::get('message')); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>

                </div>
            </div>

        </div>
    </div>
</div>

<div class="scroll-to-top"
     style="display: none;">
    <i class="fa fa-arrow-up"></i>
</div>
<?php echo $__env->make('admin.partials.javascripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('javascript'); ?>
<?php echo $__env->make('admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php /**PATH C:\xampp\htdocs\doubt_desk_app\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>