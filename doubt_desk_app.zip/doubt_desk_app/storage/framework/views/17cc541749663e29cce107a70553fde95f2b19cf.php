<?php $__env->startSection('content'); ?>

    <?php echo e(trans('quickadmin::admin.dashboard-title')); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\investor_app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>