<?php $__env->startSection('content'); ?>

    <p><?php echo link_to_route('addcategory', trans('quickadmin::admin.users-index-add_new'), [], ['class' => 'btn btn-success']); ?></p>

    <?php if($Categories->count() > 0): ?>
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">Category List</div>
            </div>
            <div class="portlet-body">
                <table id="datatable" class="table table-striped table-hover table-responsive datatable">
                    <thead>
                    <tr>
                        <th><?php echo e(trans('quickadmin::admin.users-index-name')); ?></th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>&nbsp;</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($Categorie->category_name); ?></td>
                            <td><?php echo e($Categorie->category_description); ?></td>
                            <td><img  style="border-radius: 50%;height: 50px;width: 80px;"  src="<?php echo asset("uploads/Category/{$Categorie->id}/photo/{$Categorie->category_photo}")?>"></td>
                            <td><?php echo link_to_route('editcategory', trans('quickadmin::admin.users-index-edit'), [$Categorie->id], ['class' => 'btn btn-xs btn-info']); ?>

                            <?php echo Form::open(['style' => 'display: inline-block;', 'method' => 'DELETE', 'onsubmit' => 'return confirm(\'' . trans('quickadmin::admin.users-index-are_you_sure') . '\');',  'route' => array('deletecategory', $Categorie->id)]); ?>

                                <?php echo Form::submit(trans('quickadmin::admin.users-index-delete'), array('class' => 'btn btn-xs btn-danger')); ?>

                                <?php echo Form::close(); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php else: ?>
        <?php echo e(trans('quickadmin::admin.users-index-no_entries_found')); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doubt_desk_app\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>