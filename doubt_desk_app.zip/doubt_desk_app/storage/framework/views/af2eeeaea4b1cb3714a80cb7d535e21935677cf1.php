</body>
</html><?php /**PATH C:\xampp\htdocs\investor_app\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>