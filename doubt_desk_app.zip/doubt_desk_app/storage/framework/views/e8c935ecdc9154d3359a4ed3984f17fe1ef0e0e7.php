<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-10 col-sm-offset-2">
            <h1>Create Main Category</h1>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php echo implode('', $errors->all('
                        <li class="error">:message</li>
                        ')); ?>

                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php echo Form::open(['files' => true,'route' => 'savecategory', 'class' => 'form-horizontal']); ?>


    <div class="form-group">
        <?php echo Form::label('category_name', trans('Category Name'), ['class'=>'col-sm-2 control-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::text('category_name', old('category_name'), ['class'=>'form-control', 'placeholder'=> trans('Category Name')]); ?>

        </div>
    </div>

    <div class="form-group">
        <?php echo Form::label('category_description', trans('Category Description'), ['class'=>'col-sm-2 control-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::text('category_description', old('category_description'), ['class'=>'form-control', 'placeholder'=> trans('Category Description')]); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12">
        <div class="form-group">
            <strong>Category Photo</strong>
            <?php echo Form::file('category_photo', array('class' => 'form-control')); ?>

        </div>     
    </div>

    <div class="form-group">
        <div class="col-sm-10 col-sm-offset-2">
            <?php echo Form::submit(trans('quickadmin::admin.users-create-btncreate'), ['class' => 'btn btn-primary']); ?>

        </div>
    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doubt_desk_app\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>