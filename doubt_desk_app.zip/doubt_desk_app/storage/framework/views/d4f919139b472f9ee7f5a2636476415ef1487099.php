<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $Blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card" style="width:250px">
  <img class="card-img-top" style="height: 100px;width: 100px;" src="<?php echo asset("uploads/Blog/{$Blog->id}/photo/{$Blog->banner_image}")?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title"><?php echo e($Blog->title); ?></h4>
    <p class="card-text"><?php echo e($Blog->content); ?></p>
    <a href="#" class="btn btn-primary">Read More</a>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doubt_desk_app\resources\views/admin/articles/index.blade.php ENDPATH**/ ?>