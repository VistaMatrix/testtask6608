<?php $__env->startSection('content'); ?>

    <p><?php echo link_to_route('addblog', trans('quickadmin::admin.users-index-add_new'), [], ['class' => 'btn btn-success']); ?></p>

    <?php if($Blogs->count() > 0): ?>
        <div class="portlet box green">
            <div class="portlet-title">
                <div class="caption">Blog List</div>
            </div>
            <div class="portlet-body">
                <table id="datatable" class="table table-striped table-hover table-responsive datatable">
                    <thead>
                    <tr>
                        <th>Heading</th>
                        <th>Title</th>
                        <th>Content</th>
                        <th>Banner Images</th>
                        <th>&nbsp;</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $Blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($Blog->heading); ?></td>
                            <td><?php echo e($Blog->title); ?></td>
                            <td><?php echo e($Blog->content); ?></td>
                            <td><img  style="border-radius: 50%;height: 50px;width: 80px;"  src="<?php echo asset("uploads/Blog/{$Blog->id}/photo/{$Blog->banner_image}")?>"></td>
                            <td><?php echo link_to_route('editblog', trans('quickadmin::admin.users-index-edit'), [$Blog->id], ['class' => 'btn btn-xs btn-info']); ?>

                            <?php echo Form::open(['style' => 'display: inline-block;', 'method' => 'DELETE', 'onsubmit' => 'return confirm(\'' . trans('quickadmin::admin.users-index-are_you_sure') . '\');',  'route' => array('deleteblog', $Blog->id)]); ?>

                                <?php echo Form::submit(trans('quickadmin::admin.users-index-delete'), array('class' => 'btn btn-xs btn-danger')); ?>

                                <?php echo Form::close(); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php else: ?>
        <?php echo e(trans('quickadmin::admin.users-index-no_entries_found')); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doubt_desk_app\resources\views/admin/blog/index.blade.php ENDPATH**/ ?>