<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
// -------------for---------admin------------------
Route::get('/home', 'HomeController@index')->name('home');

Route::get('/blog', 'BlogController@index')->name('blog');
Route::get('/addblog', 'BlogController@create')->name('addblog');
Route::post('/saveblog', 'BlogController@store')->name('saveblog');
Route::get('/editblog/{id}', 'BlogController@edit')->name('editblog');
Route::patch('/updateblog/{id}', 'BlogController@update')->name('updateblog');
Route::delete('/deleteblog/{id}', 'BlogController@destroy')->name('deleteblog');



// ----------for-----------------users--------------------

Route::get('/articles', 'BlogViewController@index')->name('articles');


