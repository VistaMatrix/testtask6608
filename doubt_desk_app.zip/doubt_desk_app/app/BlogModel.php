<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlogModel extends Model
{
  protected $table = 'blog'; 
  protected $fillable = ['heading', 'title','content','banner_image','status','created_by'];
}
