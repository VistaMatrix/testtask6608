<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\BlogModel;
use Auth;

class BlogController extends Controller
{
   public function index()
    {
        $Blogs = BlogModel::all();
       
        return view('admin.blog.index', compact('Blogs'));
    }

    public function create()
    {

        return view('admin.blog.create');
    }

    public function store(Request $request)
    {
        // $input = $request->all();

        $Blogs= new BlogModel();
    	$Blogs->heading=$request->input('heading');
    	$Blogs->title=$request->input('title');
    	$Blogs->content=$request->input('content');
    	$Blogs->created_by=Auth::user()->id;
        $Blogs->status = $request->input('status') ? true : false;
    	$Blogs->save();
    	if($file = $request->hasFile('banner_image')) {            
            $file = $request->file('banner_image') ;            
            $fileName = $file->getClientOriginalName() ;
            $destinationPath = public_path().'/uploads/'.'/'.'/Blog/'.$Blogs->id.'/'.'/photo/' ;
            $file->move($destinationPath, $fileName);
            $Blogs->banner_image = $fileName;
        }
        $Blogs->update();
    	

        return redirect()->route('blog')->withMessage(trans('Blog created successfully'));
    }

    public function edit($id)
    {
        $Blogs  = BlogModel::findOrFail($id);

        return view('admin.blog.edit', compact('Blogs'));
    }

    public function update(Request $request, $id)
    {
        $Blogs = BlogModel::where('id',$id)->first();
        // echo $Blogs;
        // exit;

        // $input = $request->all();
        $Blogs->heading=$request->input('heading');
    	$Blogs->title=$request->input('title');
    	$Blogs->content=$request->input('content');
    	$Blogs->created_by=Auth::user()->id;
        $Blogs->status = $request->input('status') ? true : false;
        if($file = $request->hasFile('banner_image')) {            
            $file = $request->file('banner_image') ;            
            $fileName = $file->getClientOriginalName() ;
            $destinationPath = public_path().'/uploads/'.'/'.'/Blog/'.$request->id.'/'.'/photo/' ;
            $file->move($destinationPath, $fileName);
            $Blogs->banner_image = $fileName;
        }
        $Blogs->save();

        return redirect()->route('blog')->withMessage(trans('Blog updated Successfully'));
    }

    public function destroy($id)
    {
        $Blogs = BlogModel::findOrFail($id);
        BlogModel::destroy($id);

        return redirect()->route('blog')->withMessage(trans('Blog deleted Successfully'));
    }
}
