<?php

namespace App\Http\Controllers\Api;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use Illuminate\Routing\ResponseFactory;
use Validator;
use App\User;
use App\Register;
use App\State;
use App\Country;
use App\City;
use App\Board;
use App\ViewCount;
use App\Freeslider;
use App\Otp;
use Hash;
use App\ClassManagement;
use App\SubjectManagement;
use App\VideosManagement;
use App\QuizManagement;
use App\PlaylistManagement;
use Auth;
use DateTime;
use App\Slider;
use App\Plan;
use App\AttemptQuiz;
use App\Watchlist;
use App\Subscriptions;
use App\Transactions;
use Mail;
use App\Notifications;
use DB;


//use App\Http\Controllers\Traits\FileUploadTrait;


class Apicontroller extends BaseController
{
    protected $statusCode = 200;
    
    
    
public function sendGCM($id='',$message='', $image='',$type='',$linkType='') {


 
//$type 1 is for usersList
//$type 2 for class

if($linkType==1){
$image=$this->getURLTIIMG($image);
} 	

if($type=='class'){
$listusers=Register::select('id','firebase_id','email','name')->whereIn('class_id',$id)->get()->toArray();
}
 
 
 
if($type=='user'){
$listusers=Register::select('id','firebase_id','email','name')->whereIn('id',$id)->get()->toArray();
}   



if($type=='all'){
$listusers=Register::select('id','firebase_id','email','name')->get()->toArray();
}   



$responsecheck=[];

foreach($listusers as $listusersList){
   
   
    
     $fields = array (
            'registration_ids' => array (
                    $listusersList['firebase_id']
            ),
            'data' => array (
                    "message" => $message,
					"image"=>$image,
       // "action"=> "url",
      //  "action_destination"=> "http://androiddeft.com"
            )
    );
    
    $responsecheck[]=array($this->sendGCMSENDER($fields),$listusersList['email'],$listusersList['name']);
    
    
}


 
   return $responsecheck;

 
}


public function sendGCMSENDER($fields) {
    

    $url = 'https://fcm.googleapis.com/fcm/send';

   
    $fields = json_encode ( $fields );

    $headers = array (
            'Authorization: key=' . "AAAAryEZ3Mw:APA91bHtv-6-jm1osV8uXgQMrG3TrWZ01dvP98D79onRx2e9_0q5WDM4mUq4lg4yoNmuTYoaMluK3Cv1HSSv4iFsjcNL9H23e_hrQb2U4aK1k9d3ymmc1DbEs5auWnN_6N_OJla2zPIj",
            'Content-Type: application/json'
    );

    $ch = curl_init ();
    curl_setopt ( $ch, CURLOPT_URL, $url );
    curl_setopt ( $ch, CURLOPT_POST, true );
    curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
    curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields );

    $result = curl_exec ( $ch );
    //echo $result;
	$result=json_decode($result);
    curl_close ( $ch );
	
	
// return $result;
}





     public function index2(Request $request)
    {
      
       $id=[48];
        return $this->sendGCM($id,'Your OTP is: 54544', '','user','');
    
      

    }
    
    
    public function SMSOTP($number='')
		{
			
			if($number)
			{
			// $otp=rand(0,9999);
			 $digits = 4;
			$otp= rand(pow(10, $digits-1), pow(10, $digits)-1);
			//$otp= 9467;
			 
			//this->Emailotp($to='',$name,$otp,$getuser);
			 //http://priority.thesmsworld.com/api.php?username=HOLYBM&password=725695&sender=HOLYBM&sendto=918171161278&message=%3C%23%3E+Your+Holybasil+Login+OTP+is+%3A+9467

			$messageSender='http://priority.thesmsworld.com/api.php?username=ChetanBharat&password=149307&sender=EDUCBL&sendto=91'.$number.'&message='.urlencode ('<#> Your CBL OTP is : '.$otp);


			  
			
			$this->curl_get_contents($messageSender);
							return $otp;
						}else{
						return '1234';	
						}

					}


function curl_get_contents($url)
				{
				  $ch = curl_init($url);
				  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
				  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				  $data = curl_exec($ch);
				  curl_close($ch);
				  return $data;
				}

    public function check(Request $request)
    {
     
        $rules = array(
            'username' => 'required',
            'password' => 'required',

        );

       
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
		}
		else {

            $user = Register::where(['rollno' => $request->username])->get();
         
	    	 $totalCheck=$user->count();
		    $user->toArray();
		 $checkpass=2;
		 if (isset($user) and !empty($user) and $totalCheck > 0) {
                
              
                for($ch=0;$ch < $totalCheck; $ch++ ){
               
                            
           
                if(Hash::check($request->password, $user[$ch]['password'])){
     

              $checkpass=1;
 
                    $user[$ch]['token'] = md5(time() . rand());
                    if($request->firebase_id){
                    $user[$ch]['firebase_id']=$request->firebase_id;
                       Register::where(['id' => $user[$ch]['id']])->update(['firebase_id'=>$request->firebase_id,'token'=>$user[$ch]['token']]);
                    }
     
        
                    $user = Register::where(['id' => $user[$ch]['id']])->first();
					
					if(isset($user['image']) and !empty($user->image)){
						$user['image']=url('/uploads/'.$user->image);
					}
 
                    $response['status']=TRUE;
                $response['data']=$user;
                $response['message']='successfully registered';



 }
  
 
 
 
               
                }
                
                	 if($checkpass==2){
		     
		      $response['status']=FALSE;
                $response['data']=NULL;
                $response['message']='Password Not Matched!!'; 
		 }
		 
                
		 }else {

                $response['status']=FALSE;
                $response['data']=NULL;
                $response['message']='falied';

             } 
		 
	
		    


        }
        
         return $this->respond($response);
    }
    public function register(Request $request)
    {
        $d = $request->all();
		// print_r($d);
		// die();
		
       // $otp =  mt_rand(100000,999999);
       $rollno=rand(000000,999999);
       $otp=$this->SMSOTP($request['parent_mobile']);
        $reg = array(

            'name' => $request->name,
            'email' => $request->email,
            'mobile_no' => $request->mobile_no,
            'parent_mobile' =>$request['parent_mobile'],
            'parent_name' => $request->parent_name,
            'password' =>Hash::make($request->password),
            'token' => md5(time()),
            'class_id' => $request->class_id,
            'school' => $request->school,
            'board_id' => $request->board_id,
            'state' => $request->state,
            'district' => $request->district,
            'city' => $request->city,
            'firebase_id' => $request->firebase_id,
            'device' => $request->device,
            'status' => 0,
            'otp' => $otp,
            'rollno'=>$rollno,
			'access_token'=>$request->access_token,
           
        );
        
     $datass=Register::create($reg);
     $datass=$datass->id;
     $last =  Register::select('id','token')->orderBy('created_at', 'desc')->first();
     $start_date=date('Y-m-d');
     $end_date=date('Y-m-d', strtotime("+30 days"));
     $plan = array(

            'user_id' => $datass,
            'start_date' =>$start_date,
            'end_date' =>$end_date
            );
    $plandetail=Subscriptions::create($plan);     
     if (isset($last) and !empty($last)) {
    
         $id=[$last->id];
         //$this->sendGCM($id,'Your OTP is: '.$otp, '','user','');
        	
         $response['status']=TRUE;
         $response['data']=$last->id;
         $response['plan_name']='Trial';
         $response['start_date']=$start_date;
         $response['end_date']=$end_date;
         $response['token']=$last->token;
         $response['message']='successfully registered';
        
     }else{
         $response['status']=FALSE;
         $response['data']=NULL;
         $response['message']='falied';
     }
    

     return $this->respond($response);

        
    }
     public function autologout(Request $request)
    {
      
      $newtoken = md5(time() . rand());
      $register=Register::where(['id' => $request->user_id , 'token' =>$request->token ])
				->first();
	   if(isset($register) and !empty($register))
	   {
       // Register::where('id',$request->user_id)->update(['token'=>$newtoken]);
        $response['status']=TRUE;
    //    $response['token']=$newtoken;
	   }else{
            $response['status']=FALSE;
	   }
	    return $this->respond($response);
        
    }
    public function otpverify(Request $request)
    {
        $otp = $request->all();
    // 	   print_r($otp);
    //   die();
      $user = Register::where(['parent_mobile' => $request->phone , 'otp' =>$request->otp ])
				->first();
				//   print_r($user);
    //   die();
        // $otp =  Register::select('otp')->where('id', $request->id)->first();
        if (isset($user) and !empty($user))
        {
            $data=$user['rollno'];
            $messageSender='http://priority.thesmsworld.com/api.php?username=ChetanBharat&password=149307&sender=EDUCBL&sendto=91'.$user['parent_mobile'].'&message='.urlencode ('Dear '.$user['parent_name']."\n".'Your RollNo for Login is  :- '."\n\n".''.$data."\n\n".'');
			$this->curl_get_contents($messageSender);


            $user = Register::where(['id' => $user['id']])->first();

            if(isset($user['image']) and !empty($user['image'])){
                $user['image']=url('/uploads/'.$user['image']);
            }



            $response['status']=TRUE;
           $response['data']=$user;
            $response['message']='success';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied no user found';
        }
       

        return $this->respond($response);

    }
    public function respond($data, $headers = [])
    {
        return response()->json($data, $this->getStatusCode(), $headers);
    }
    public function getStatusCode()
    {
        return $this->statusCode;
    }
    public function getclass(Request $request)
    {
        $list=ClassManagement::select('id','name')->get()->toArray();
		
        if (isset($list) and !empty($list)) {
             $response['status']=TRUE;
             $response['data']=$list;
             $response['message']='classes';
            
         }else{
             $response['status']=FALSE;
             $response['data']=NULL;
             $response['message']='falied';
         }
        
    
         return $this->respond($response);
    }
    
      public function search(Request $request)
      {
      if($request->user_id == 0 and $request->class_id == 0)
		{
		    	$videoRid=VideosManagement::select('id','title','url','description')
         	->where('title','LIKE',"%".$request->keyword."%")
			 ->orwhere('description','LIKE',"%".$request->keyword."%")
                    ->take(40)
		->get()->toArray();
		
		}else{
		    	$videoRid=VideosManagement::select('id','title','url','description','classmanagement_id','image')
         		->Where('classmanagement_id',$request->class_id)
         	->where('title','LIKE',"%".$request->keyword."%")
			 ->orWhere('description','LIKE',"%".$request->keyword."%")
			 	->Where('classmanagement_id',$request->class_id)
                    ->take(40)
		->get()->toArray();
		}
         
		for($i=0; $i < sizeof($videoRid); $i++)
		{
			$videoRid[$i]['image']=$videoRid[$i]['image'];
		//	$videoRid[$i]['video_id']=$this->GetLinktovideoId($videoRid[$i]['url']);
		}
         if (isset($videoRid) and !empty($videoRid)) {
            $response['status']=TRUE;
            $response['data']=$videoRid;
            $response['message']='matched';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
        
    }
	 public function getclass1(Request $request)
    {
        $list=ClassManagement::select('id','name')->get()->toArray();
		$aa = array(array('id'=>0,'name'=>'Class'));
		$data = array_merge($aa,$list);
        if (isset($list) and !empty($list)) {
             $response['status']=TRUE;
             $response['data']=$data;
             $response['message']='classes';
            
         }else{
             $response['status']=FALSE;
             $response['data']=NULL;
             $response['message']='falied';
         }
        
    
         return $this->respond($response);
    }
    public function getclasses($id='')
    {
        $list=ClassManagement::select('id','name')->where('id',$id)->first();
        if (isset($list) and !empty($list)) {
            $response['status']=TRUE;
            $response['data']=$list;
            $response['message']='classes';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
  
    }
    // public function getclassbyid($id='')
    // {
        // $list=ClassManagement::select('id','name')->where('id',$id)->first();
        // return $list;
  
    // }
    public function getsubject(Request $request)
    {
        $sub = SubjectManagement::select('id','name','classmanagement_id','position')
        ->orderBy('position','ASC')
        ->get()->toArray();
         if (isset($sub) and !empty($sub)) {
            $response['status']=TRUE;
            $response['data']=$sub;
            $response['message']='classes';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
         return $this->respond($response);
    }
    public function getstate(Request $request)
    {
        $state=State::select('id','name')->orderBy('name','ASC')->get()->toArray();
        
        
      
        
		$aa = array(array('id'=>0,'name'=>'STATE'));
	
        if (isset($state) and !empty($state)) {
            
              for($i=0;$i < sizeof($state); $i++){
            $state[$i]['name']=ucwords(strtolower($state[$i]['name']));
            
        }
       	$data = array_merge($aa,$state);
       
       
             $response['status']=TRUE;
             $response['data']=$data;
             $response['message']='list of state';
            
         }else{
             $response['status']=FALSE;
             $response['data']=NULL;
             $response['message']='falied';
         }
        
    
         return $this->respond($response);
    }
    public function getdistrict(Request $request)
    {
        
        if($request->id){
            $request->id=$request->id;
        }else{
            $request->id=0;
        }
        
        $dist=City::select('id','city')->where('state_id',$request->id)->orderBy('city','ASC')->get()->toArray();
		$aa = array(array('id'=>0,'city'=>'DISTRICT'));
	
        if (isset($dist) and !empty($dist)) {
            
              for($i=0;$i < sizeof($dist); $i++){
            $dist[$i]['city']=ucwords(strtolower($dist[$i]['city']));
            
        }
        	$data = array_merge($aa,$dist);
        
            $response['status']=TRUE;
            $response['data']=$data;
            $response['message']='list of state';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
    }
    public function getboard(Request $request)
    {
		 
        $board=Board::select('id','name')->get()->toArray();
		$aa = array(array('id'=>0,'name'=>'BOARD'));
		$data = array_merge($aa,$board);
        if (isset($board) and !empty($board)) {
             $response['status']=TRUE;
			 
			
             $response['data']=$data;
             $response['message']='school Board';
            
         }else{
             $response['status']=FALSE;
             $response['data']=NULL;
             $response['message']='falied';
         }
        
    
         return $this->respond($response);
    }
    public function getsubjectbyid(Request $request)
    {
         $subject=SubjectManagement::select('id','name')->where('classmanagement_id',$request->name)->first();
         return $subject;
    }
    public function forgotpassword(Request $request)
    {
        // $d = $request->all();
        // echo "<pre>";
        // print_r($d);
        $fpass=Register::select('id','name')->where('mobile_no',$request->phone)->first();
        if (isset($fpass) and !empty($fpass)) {
            
            $OTP=$this->SMSOTP($request->phone);
            $fpass->password=Hash::make($OTP);
            $fpass->save();
            
            $response['status']=TRUE;
            $response['data']=$fpass;
            $response['message']='matched';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
       
    }
    
    public function newforgotpassword(Request $request)
    {
        // $d = $request->all();
        // echo "<pre>";
        // print_r($d);
        $fpass=Register::select('id','name','parent_mobile','rollno')->where('rollno',$request->phone)->first();
       // print_r($fpass);
        if (isset($fpass) and !empty($fpass)) {
            
			$OTP=$this->SMSOTP($fpass->parent_mobile);
			$user=Register::where('rollno',$request->phone)->update(['otp'=>$OTP]);
            // $fpass->password=Hash::make($OTP);
            // $fpass->save();
            
            $response['status']=TRUE;
            $response['data']=$fpass;
            $response['message']='matched';
           
        }else{
            $response['status']=FALSE;
            $response['data']='';
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
       
	}
	public function setnewpassword(Request $request)
    {
        // $d = $request->all();
        // echo "<pre>";
        // print_r($d);
        $fpass=Register::select('id','name','otp','parent_mobile','rollno')->where('rollno',$request->phone)->first();
        // print_r($fpass);
        // die();
        if (isset($fpass) and !empty($fpass)) {
            
			if($request->otp == $fpass->otp)
			{
				$password=Hash::make($request->password);
				$user=Register::where('parent_mobile',$request->phone)->update(['password'=>$password]);
               
				$response['status']=TRUE;
           	 	$response['data']=$request->phone;
          	 	 $response['message']='password changed successfully';
			}else{
				$response['status']=FALSE;
				$response['data']=NULL;
				$response['message']='otp not matched';
			}
            
            
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='Mobile No. Not Valid ';
        }
       
   
        return $this->respond($response);
       
    }
    public function playlist(Request $request)
    {
        // $d = $request->all();
        // echo "<pre>";
        // print_r($d);
        $play=VideosManagement::select('id','title','url','description')->where('id',$request->playlist)->get()->toArray();
        if (isset($play) and !empty($play)) {
            $response['status']=TRUE;
            $response['data']=$play;
            $response['message']='success';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
		
        return $this->respond($response);
       
    }
	// get quiz detail before quiz start
    public function getquizdetail(Request $request)
    {
        // $d = $request->all();
        // echo "<pre>";
        // print_r($d);
    
        $tdate=date("Y-m-d");
          $month= date("m", strtotime($tdate));
        $year= date("Y", strtotime($tdate));
	     //$from=$month."-01";
         
	   $watchlist=Attemptquiz::whereMonth('created_at',$month)
	   ->whereYear('created_at',$year)
	   ->where('video_id',$request->video_id)
	   ->where('user_id',$request->user_id)
	   ->get()->toArray();
	   if(isset($watchlist) and !empty($watchlist))
	   {
	       $attempt=2;
	   }else{
	        $attempt=1;
	   }
        $quiz=VideosManagement::select('title','description','id')->where('id',$request->video_id)->first();
		$quizcount = QuizManagement::where('videomanagement_id',$quiz['id'])->count();
		$quizdetail=array(
				'title'=>$quiz['title'],
				'description'=>$quiz['description'],
				'total_questions'=>$quizcount,
				
				);
        if(isset($quizdetail) and !empty($quizdetail) and $quizcount!==0) {
            $response['status']=TRUE;
        	$response['attempt']=$attempt;
            $response['data']=$quizdetail;
            $response['message']='success';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='false';
        }
       
   
        return $this->respond($response);
       
    }
	// quiz question when quiz start
	 public function getquiz(Request $request)
    {
        $quiz=QuizManagement::select('id','question','choice1','choice2','choice3','choice4','correctansdes')->where('videomanagement_id',$request->video_id)->get()->toArray();
	   $Aquiz=array();
	   $unique_id=rand();
	   if (isset($quiz) and !empty($quiz)) {
		   foreach($quiz as $quizs){
			   $Aquiz=array(
			   'unique_id'=>$unique_id,
				'question_id'=>$quizs['id'],
				'user_id'=>$request['user_id'],
				'video_id'=>$request['video_id'],
				'status'=>0
			   );
			 AttemptQuiz::create($Aquiz);
			 
		   }
		   
            $response['status']=TRUE;
			$response['user_id']=$request->user_id;
			$response['unique_id']=$unique_id;
            $response['data']=$quiz;
            $response['message']='success';

        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }

		
        return $this->respond($response);
       
    }
	//single question update
	public function previoussinglequestion(Request $request)
	{
	    	$result=AttemptQuiz::where('video_id',$request->video_id)
			->where('unique_id',$request->unique_id)
			->where('question_id',$request->question_id)
			->first();
			
		if (isset($result) and !empty($result)) {
            $response['status']=TRUE;
			$response['answer']=$result->answer;
			//$response['data']=$Dataup;
            $response['message']='success';
           
        }else{
            $response['status']=FALSE;
            $response['data']='';
            $response['message']='falied';
        }
		return $this->respond($response);

			
			
	}
	public function QuizQuestionupdate(Request $request)
	{
		 $answer = $request->answer;
		 if($request->answer == 0 and $request->review == 100)
		 {
			 $status=0;
			 $point=0;
			 $review=1;
		 }elseif($request->answer !== 0 and $request->review == 100 ){
		     
			  $qq = $this->GetQuizanswer($request->question_id);
			  
			  if($request->answer == $qq){
				  $point=2;
				  $status=1;
				  	 $review=1;
		
			  }elseif($request->answer !== $qq){
			      $point=1;
			      $status=1;
			      	 $review=1;
			  }
		 }else{
		     $qq = $this->GetQuizanswer($request->question_id);
			  
			  if($request->answer == $qq){
				  $point=2;
				  $status=1;
				  $review=0;
		
			  }elseif($request->answer !== $qq){
			      $point=1;
			      $status=1;
			      	 $review=0;
			  }
		 }
	        
			$update=array(
				'answer'=>$answer,
				'status'=>$status,
				'point'=>$point,
				'reviewlater'=>$review
			);
// 			print_r($update);
// 			die();
			AttemptQuiz::where('unique_id',$request->unique_id)
			->where('question_id',$request->question_id)
			->update($update);
		
		return $update;
	}
	// when submit show result 
	
    public function attempt(Request $request)
	{
		$d = $request->all();
		
		$dataupdate=AttemptQuiz::select('status','user_id','answer','question_id','video_id')
		        ->where('video_id',$request->video_id)
				->where('unique_id',$request->unique_id)
				->where('user_id',$request->user_id)
				->get()->toArray();
		$Dataup=array();	
		 $correct_ans=[];
		 $Incorrect_ans=[];
		 $unattempt_ans=[];
		foreach($dataupdate as $dataupdates)	
		{
			$totalQuestion[]=
			  $qq = $this->GetQuizanswer($dataupdates['question_id']);
			  
			  if($dataupdates['answer']==$qq and $dataupdates['status'] == 1){
				  $correct=1;
				   $correct_ans[]=1;
		
			  }elseif($dataupdates['status'] == 1 and $dataupdates['answer'] !== $qq){
				  $correct=0;
				   $Incorrect_ans[]=1;
				   
			  }else{
				  $correct=2;
				   $unattempt_ans[]=1;
			  }
			  
			$Dataup[]=array(
					'question_id'=>$dataupdates['question_id'],
					'answer'=>$dataupdates['answer'],
					'canswer'=>$qq,
					'is_correct'=>$correct,
					
			);

    //   print_r($Dataup);
    //   die();
		}
		

		
		 if (isset($Dataup) and !empty($Dataup)) {
            $response['status']=TRUE;
			$response['totalquestion']=sizeof($dataupdate);
			$response['correct']=sizeof($correct_ans);
			$response['incorrect']=sizeof($Incorrect_ans);
			$response['unattempt']=sizeof($unattempt_ans);
			//$response['data']=$Dataup;
            $response['message']='success';
           
        }else{
            $response['status']=FALSE;
            $response['data']='';
            $response['message']='falied';
        }
		return $this->respond($response);
	}
	// quiz result description
	public function quizresult(Request $request)
	{
	$result=AttemptQuiz::select('status','user_id','answer','question_id','video_id')
			->where('video_id',$request->video_id)
			->where('unique_id',$request->unique_id)
			->get()->toArray();
// 	print_r($result);
// 	die();
    	foreach($result as $results)	
		{
			  $qr = $this->GetQuizans($results['question_id']);
			  
			  if($results['answer']==$qr['answer'] and $results['status'] == 1){
				  $result='Correct';
			  }elseif($results['status'] == 1 and $results['answer'] !== $qr['answer']){
				  $result='Incorrect';
			  }else{
			      $result='Unattempt';
			  }
			$resultdata[]=array(
					'user_answer'=>$results['answer'],
					'result'=>$result,
					'question'=>$qr
					
			);

       //print_r($Dataup);
		}
		if (isset($resultdata) and !empty($resultdata)) {
            $response['status']=TRUE;
			$response['data']=$resultdata;
            $response['message']='success';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
		return $this->respond($response);
		
		
	}
		public function quizpreview(Request $request)
	{
	$result=AttemptQuiz::select('status','user_id','answer','question_id','video_id','reviewlater')
			->where('video_id',$request->video_id)
			->where('unique_id',$request->unique_id)
			->get()->toArray();
// 			print_r($result);
// 			die();
        $i=1;
    	foreach($result as $results)	
		{
			  $qr = $this->GetQuizans2($results['question_id'],$results['answer']);
			  
			  if($results['status'] == 1 and $results['reviewlater'] == 0 and $results['answer'] !== 0){
				  $result='attempted';
			  
			  }
			 // elseif($results['status'] == 1 and $results['answer'] !== $qr['answer'] and $results['reviewlater'] == 0 ){
				//   $result='Unattempt';
			
			 // }
			  elseif($results['reviewlater'] == 1){
			      $result='review';
			  }else
			  {
			      $result='unattempted';
			  }
			$resultdata[]=array(
					'user_answer'=>$results['answer'],
					'result'=>$result,
					'number'=>$i++,
					'questions'=>$qr
					
			);

       //print_r($Dataup);
		}
		if (isset($resultdata) and !empty($resultdata)) {
            $response['status']=TRUE;
			$response['data']=$resultdata;
            $response['message']='success';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
		return $this->respond($response);
		
		
	}
	
	
	
	public function GetQuizanswer($qid)
	{
		
		$quiz=QuizManagement::select('id','answer','correctansdes')->where('id',$qid)->first();
	if(isset($quiz['answer'])){
		return $quiz['answer'];
		
	}
	
		 
	}
		public function GetQuizans2($qqid,$qans)
	{
		
		$quizz=QuizManagement::select('id','question','choice1','choice2','choice3','choice4','correctansdes','wrongansdes','answer')->where('id',$qqid)->first();
		
	 
				$newQuiz=array(
    				'id'=>$quizz['id'],
    				'question'=>$quizz['question'],
    				'choice1'=>$quizz['choice1'],
    				'choice2'=>$quizz['choice2'],
    				'choice3'=>$quizz['choice3'],
    				'choice4'=>$quizz['choice4'],
    				'correctansdes'=>$quizz['correctansdes'],
    				'answer'=>intval($qans)
				);
		 
		
		return $newQuiz;
		
	
		 
	}
	
	public function GetQuizans($qqid)
	{
		
		$quizz=QuizManagement::select('id','question','choice1','choice2','choice3','choice4','correctansdes','wrongansdes','answer')->where('id',$qqid)->first();
		
	 
				$newQuiz=array(
				'id'=>$quizz['id'],
				'question'=>$quizz['question'],
				'choice'=>array(
				array(
				'choice'=>$quizz['choice1'],
				'id'=>1
				),
				array(
				'choice'=>$quizz['choice2'],
				'id'=>2
				),
				array(
				'choice'=>$quizz['choice3'],
				'id'=>3
				),
				array(
				'choice'=>$quizz['choice4'],
				'id'=>4
				),
				
				), 
							 
				'correctansdes'=>$quizz['correctansdes'],
				'wrongansdes'=>$quizz['wrongansdes'],
				'answer'=>intval($quizz['answer'])
				);
		 
		
		return $newQuiz;
		
	
		 
	}
	// get image from url
	public function get_vimeo_thumb($vimeo)
{
	//$vimeo = 'https://vimeo.com/387381478';

    $id = (int) substr(parse_url($vimeo, PHP_URL_PATH), 1);
    //forming API url
    $url = "http://vimeo.com/api/v2/video/".$id.".json";
    //curl request
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
     $curlData = curl_exec($curl);
    curl_close($curl);
    return (json_decode($curlData, true));
    
}


public function updateVideoImages(){

    $listVideo=VideosManagement::select('id','url')->where('image',NULL)->take(50)->get()->toArray();


    if(sizeof($listVideo) > 0){

    for ($k=0;$k < sizeof($listVideo); $k++){
 $videoID = (int) substr(parse_url($listVideo[$k]['url'], PHP_URL_PATH), 1);
 
if($videoID){

        $listVideo[$k]['image']=$this->GetLinktoImage($listVideo[$k]['url']);
   
        $listVideo[$k]['hash_id']=$this->GetLinktovideoId($listVideo[$k]['url'],2);
        $VimeoData=$this->GetLinktoImage($listVideo[$k]['url'],1);
        
   
        $listVideo[$k]['duration']=$VimeoData->duration;
 



        VideosManagement::where('id',$listVideo[$k]['id'])->update(['image'=> $listVideo[$k]['image'],'hash_id'=> $listVideo[$k]['hash_id'],'duration'=>$listVideo[$k]['duration']]);
}
    }
    }
    $response['status']=True;
    $response['data']=$listVideo;
    $response['message']='Done';



return $this->respond($response);


}


	public function GetLinktoImage($url,$list='',$parameters='')
	{
			$vimeo = $url;
			  if (strpos($vimeo, 'youtube') > 0) {
			$video_id = explode("?v=", $vimeo);
			 $video_id = $video_id[1];
			 return 'https://img.youtube.com/vi/'.$video_id.'/0.jpg';
			  }else{

			      if($list){
                      $arr = \App\Http\Controllers\Controller::getVideoImage($vimeo);
                      if($parameters){
                          return $arr->$parameters;
                      }else{
                          return $arr;
                      }

                  }else{
                      $arr = \App\Http\Controllers\Controller::getVideoImage($vimeo,1);
                      return $arr;
                  }
         



			      $arr = $this->get_vimeo_thumb($vimeo);
			      return $arr[0]['thumbnail_medium'];
			  }
	}
	// get video id from url
	public function GetLinktovideoId($vidId,$key='')
	{
// 			$link = $vidId;
// 			$video_id = explode("?v=", $link);
// 			 $video_id = $video_id[1];


			  $vimeo = $vidId;


			  if (strpos($vimeo, 'youtube') > 0) {
			$video_id = explode("?v=", $vimeo);
			 $video_id = $video_id[1];
			return $video_id;
			
			  }else{
			     // $arr = $this->get_vimeo_thumb($vimeo);

                  if($key==2){

//

                      $LinkID= explode('/',parse_url($vimeo, PHP_URL_PATH));
                      
                      if(isset($LinkID[2]) and !empty($LinkID[2])){
                          
                           return $LinkID[2];
                      }else{
                          return '6fbd868051';
                      }
                     
                  }else{
                      $LinkID= (int) substr(parse_url($vimeo, PHP_URL_PATH), 1);

                  }


			      return $LinkID;
			  }
			 
			 
	}
	// // shhow banner images of playlist
    // public function playlistbanner(Request $request)
    // {
		
        // $baner=VideosManagement::select('title','url')->orderBy('id', 'desc')->take(5)->get()->toArray();
		// for($i=0; $i < sizeof($baner); $i++)
		// {
			// $baner[$i]['image']=$this->GetLinktoImage($baner[$i]['url']);
		// }
        // if (isset($baner) and !empty($baner)) {
            // $response['status']=TRUE;
            // $response['data']=$baner;
            // $response['message']='success';
           
        // }else{
            // $response['status']=FALSE;
            // $response['data']='';
            // $response['message']='falied';
        // }
       
   
        // return $this->respond($response);
    // }
	// show banner image before after login
	
	 public function testbanner(Request $request)
    {
		     
		if(!empty($request->user_id) and !empty($request->class_id))
		{
			$testbaner=Slider::select('title','image')
			 ->where('classmanagement_id',$request->class_id)
			->whereDate('start_date','<=',date('Y-m-d'))
			->whereDate('expire_date','>=',date('Y-m-d'))
			->get()->toArray();
			$resultdata=array();
			foreach($testbaner as $testbaners)	
		{
			$resultdata[]=array(
					'user_answer'=>$testbaners['title'],
					'image'=>url('/uploads/'.$testbaners['image'])
					
			);

 
		}
			if (isset($resultdata) and !empty($resultdata)) {
				$response['status']=TRUE;
				$response['data']=$resultdata;
				$response['message']='success';
			   
			}else{
// 				$videobaner=VideosManagement::select('title','url')
// 				->whereRaw('classmanagement_id',$request->class_id)
// 				->get()->toArray();
// 				for($i=0; $i < sizeof($videobaner); $i++)
// 				{
// 					$videobaner[$i]['image']=$this->GetLinktoImage($videobaner[$i]['url']);
// 				}
// 				if (isset($videobaner) and !empty($videobaner)) {
// 				$response['status']=TRUE;
// 				$response['data']=$videobaner;
// 				$response['message']='success';
			   
// 			}else{
// 				$response['status']=FALSE;
// 				$response['data']=NULL;
// 				$response['message']='falied';
// 			}
$baner=Freeslider::select('photo','id')->orderBy('id', 'desc')->take(5)->get()->toArray();
// 		print_r($baner);
// 		die();
			for($i=0; $i < sizeof($baner); $i++)
			{
				$baner[$i]['photo']=url('/uploads/'.$baner[$i]['photo']);
				$data[]=array(
				    'user_answer'=>'image',
				    'image'=>$baner[$i]['photo']
				    );
			}
			if (isset($baner) and !empty($baner)) {
				$response['status']=TRUE;
				$response['data']=$data;
				$response['message']='success';
			   
			}else{
				$response['status']=FALSE;
				$response['data']=NULL;
				$response['message']='falied';
			}
			}
		}else{
		
// 		$baner=VideosManagement::select('title','url')->orderBy('id', 'desc')->take(5)->get()->toArray();
		$baner=Freeslider::select('photo','id')->orderBy('id', 'desc')->take(5)->get()->toArray();
// 		print_r($baner);
// 		die();
			for($i=0; $i < sizeof($baner); $i++)
			{
				$baner[$i]['photo']=url('/uploads/'.$baner[$i]['photo']);
				$data[]=array(
				    'user_answer'=>'image',
				    'image'=>$baner[$i]['photo']
				    );
			}
			if (isset($baner) and !empty($baner)) {
				$response['status']=TRUE;
				$response['data']=$data;
				$response['message']='success';
			   
			}else{
				$response['status']=FALSE;
				$response['data']=NULL;
				$response['message']='falied';
			}
		}
        
       
   
        return $this->respond($response);
    }
	// video playlsit guest login
    public function videoplaylist(Request $request)
    {
		
        $vcideo=ClassManagement::select('id','name',DB::raw('IF(`sorting` IS NOT NULL, `sorting`, 1000000000000000000000000000) `sorting`'))
            ->orderBy('sorting','ASC')
            ->get()->toArray();



		$vclass = array();
		  foreach ( $vcideo as $videos) 
		  {

            $job = $this->Getvideo($videos['id']);

			if(isset($job) and sizeof($job) > 0){ 
            $vclass[] = array(
                //'classname'=>"Class ".$videos['name'],
                'name'=>$videos['name'],
                'video'=>$job
  
            );
			}

         }
        
        if (isset($vclass) and !empty($vclass)) {
            $response['status']=TRUE;
            $response['data']=$vclass;
            $response['message']='success';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
    }
		// video playlsit after login
	public function loginplaylist(Request $request)
    {
		$id = $request->all();

     $class_id = array_map( 'trim', explode( ",",$request->class_id ) );






      /*   $vclassbased=VideosManagement::
      // whereIn('classmanagement_id',$class_id)
            whereRaw('FIND_IN_SET('.$request->class_id.',classmanagement_id)')
            //  whereRaw('classmanagement_id in (?)', $class_id)
		    ->with('subjectmanagement')
            ->with('classmanagement')
           ->groupBy('subjectmanagement_id')
		//->take(2)
		 //->toSql();
		  ->get()
            ->toArray(); */


        $vclassbased=SubjectManagement::
        // whereIn('classmanagement_id',$class_id)
      //  whereRaw('FIND_IN_SET('.$request->class_id.',classmanagement_id)')
            //  whereRaw('classmanagement_id in (?)', $class_id)
        //    ->with('subjectmanagement')
        //    ->with('classmanagement')
         ///   ->groupBy('subjectmanagement_id')
            //->take(2)
            //->toSql();
        orderBy('position','ASC')
            ->get()
            ->toArray();





        $vclassS = array();

		  foreach ( $vclassbased as $vclassbaseds) 
		  {

           $subjc = $this->Getsubvideo3($vclassbaseds['id'],$request->class_id);

			if(isset($subjc) and sizeof($subjc) > 0){ 
			    $nameCheck='';
			    if(isset($vclassbaseds['name']) and !empty($vclassbaseds['name']))
			    {
			    $nameCheck=$vclassbaseds['name'];
                
			    }
			    
		 
            $vclassS[] = array(
				'subjectmanagement_id'=>$vclassbaseds['id'],
				'name'=>(strlen($nameCheck) > 20) ? substr($nameCheck,0,20).'..' :$nameCheck,
				//'name'=>substr($nameCheck,0,20),
				'video'=>$subjc,
			
            );
         
			}
				

			
         }	
		 if (isset($vclassS) and !empty($vclassS)) {
            $response['status']=TRUE;
            $response['data']=$vclassS;
           // $response['datsa']=sizeof($vclassS);
            $response['message']='matched';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
      // return $vclassS;
       
    }
	public function viewmorevideo(Request $request)
    {
		if($request->guest == 0)
		{
		$cls=$request->class_id;
		$vclassbased=VideosManagement::
	//	whereRaw('FIND_IN_SET("'.$cls.'",classmanagement_id)')
		where('classmanagement_id',$request->class_id)
		->where('subjectmanagement_id',$request->subject_id)
    	->with('subjectmanagement')
	//	->groupBy('subjectmanagement_id')
		->get()->toArray();
		}else
		{
		    $cls=$request->class_id;
		$vclassbased=VideosManagement::
	//	whereRaw('FIND_IN_SET("'.$cls.'",classmanagement_id)')
		where('subjectmanagement_id',$request->subject_id)
	//	->where('classmanagement_id',$cls)
        	->with('subjectmanagement')
		->groupBy('subjectmanagement_id')
		->get()->toArray();
		}
		$vclassS = array();

		  foreach ( $vclassbased as $vclassbaseds) 
		  {
           if($request->guest == 0 )
		{ 
         $subjc = $this->Getsubvideo3($vclassbaseds['subjectmanagement_id'],$vclassbaseds['classmanagement_id']);
        }else
        {
             $subjc = $this->Getsubvideo3($vclassbaseds['subjectmanagement_id'],$vclassbaseds['classmanagement_id']);
        }
			if(isset($subjc) and sizeof($subjc) > 0){ 
            $vclassS = array(
				'subjectmanagement_id'=>$vclassbaseds['subjectmanagement']['id'],
				
				'name'=>$vclassbaseds['subjectmanagement']['name'],
				'video'=>$subjc
            );
			}
			
         }
		if (isset($vclassS) and !empty($vclassS)) {
            $response['status']=TRUE;
            $response['data']=$vclassS;
           // $response['datsa']=sizeof($vclassS);
            $response['message']='matched';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
		 return $this->respond($response);
		// print_r($vclassbased);
		// die();
	}
		public function viewmorequizvideo(Request $request)
    {

		    $cls=$request->class_id;
		$vclassbased=Quizmanagement::
		whereRaw('FIND_IN_SET("'.$cls.'",classmanagement_id)')
	//	where('subjectmanagement_id',$request->subject_id)
        	->with('subjectmanagement')
        	//	->with('subjectmanagement')
		->groupBy('videomanagement_id')
		->get()->toArray();
// 		print_r($vclassbased);
// 		die();
		$vclassS = array();

		  foreach ( $vclassbased as $vclassbaseds) 
		  {
 
             $subjc = $this->GetsubvideoRealted($vclassbaseds['videomanagement_id']);
        
			if(isset($subjc) and sizeof($subjc) > 0){ 
            $vclassS[] = array(
				'subjectmanagement_id'=>$vclassbaseds['subjectmanagement']['id'],
				'name'=>$vclassbaseds['subjectmanagement']['name'],
				'video'=>$subjc
            );
			}
			
         }
		if (isset($vclassS) and !empty($vclassS)) {
            $response['status']=TRUE;
            $response['data']=$vclassS;
           // $response['datsa']=sizeof($vclassS);
            $response['message']='matched';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
		 return $this->respond($response);
		// print_r($vclassbased);
		// die();
	}
	
    public function Getvideo($vid)
    {
        $vd=VideosManagement::select('id','title','url','image',DB::raw('IF(`sorting` IS NOT NULL, `sorting`, 1000000000000000000000000000) `sorting`'))
            ->orderBy('sorting','ASC')->where('classmanagement_id',$vid)->get()->toArray();
		 for($i=0; $i < sizeof($vd); $i++)
		{
			$vd[$i]['image']=$vd[$i]['image'];
		}
        return $vd;
		
    }
	public function Getsubvideo($subj)
	{
		// print_r($_REQUEST['class_id']);
		// die();
		$vclasssub=VideosManagement::select('id','title','url','image')
		->where('classmanagement_id',$subj)
		->get()->toArray();
		for($i=0; $i < sizeof($vclasssub); $i++)
		{
			$vclasssub[$i]['image']=$vclasssub[$i]['image'];
		}
		return $vclasssub;
	}
		public function GetsubvideoRealted($subj)
	{
		// print_r($_REQUEST['class_id']);
		// die();
		$vclasssub=VideosManagement::select('id','title','url','image')
		->where('id',$subj)
		->get()->toArray();
		for($i=0; $i < sizeof($vclasssub); $i++)
		{
			$vclasssub[$i]['image']=$vclasssub[$i]['image'];
		}
		return $vclasssub;
	}
	public function Getsubvideo2($subj)
	{
		// print_r($_REQUEST['class_id']);
		// die();
		$vclasssub=VideosManagement::select('id','title','url','image')
		->where('subjectmanagement_id',$subj)
		->get()->toArray();
		for($i=0; $i < sizeof($vclasssub); $i++)
		{
			$vclasssub[$i]['image']=$vclasssub[$i]['image'];
		}
		return $vclasssub;
	}
		public function Getsubvideo3($subj,$clsid)
	{
		// print_r($_REQUEST['class_id']);
		// die();
		$vclasssub=VideosManagement::select('id','title','url','playlistmanagement_id','image')
		->where('subjectmanagement_id',$subj)
             ->whereRaw('FIND_IN_SET('.$clsid.',classmanagement_id)')
		//->where('classmanagement_id',$clsid)
		->get()->toArray();
		
		for($i=0; $i < sizeof($vclasssub); $i++)
		{
		     if (strpos($vclasssub[$i]['url'], 'youtube') > 0) {
		         $vclasssub[$i]['url']=$vclasssub[$i]['url'];
		         	$vclasssub[$i]['image']=$this->GetLinktoImage($vclasssub[$i]['url']);
		         	$vclasssub[$i]['playlistmanagement_id']=1;
		         $vclasssub[$i]['type']=$vclasssub[$i]['playlistmanagement_id'];
			  }
			  else
			  {
			       $id = (int) substr(parse_url($vclasssub[$i]['url'], PHP_URL_PATH), 1);
			       $vclasssub[$i]['image']=$vclasssub[$i]['image'];
			        $vclasssub[$i]['url']=$vclasssub[$i]['url'];
                     $vclasssub[$i]['vimeo_id']=$id;
                 	$vclasssub[$i]['playlistmanagement_id']=2;
                 	 $vclasssub[$i]['type']=$vclasssub[$i]['playlistmanagement_id'];
          
                
			  }
		
		}
		return $vclasssub;
	}
	
	// get related video with video id
	public function getrelatedvideo($reltedid)
	{
		$videoRid=VideosManagement::select('id','title','url','subjectmanagement_id','classmanagement_id','playlistmanagement_id','duration','hash_id','image')
		->where('classmanagement_id',$reltedid)->get()->toArray();
		
		for($i=0; $i < sizeof($videoRid); $i++)
		{



		    if (strpos($videoRid[$i]['url'], 'youtube') > 0) {
		         $vclasssub[$i]['url']=$videoRid[$i]['url'];
		         	$videoRid[$i]['playlistmanagement_id']=1;
                $videoRid[$i]['hash_id']=$this->GetLinktovideoId($videoRid[$i]['url'],2);

                $videoRid[$i]['type']=$videoRid[$i]['playlistmanagement_id'];
		         	$videoRid[$i]['image']=$this->GetLinktoImage($videoRid[$i]['url']);
			$videoRid[$i]['video_id']=$this->GetLinktovideoId($videoRid[$i]['url']);
			  }
			  else
			  {
			       $id = (int) substr(parse_url($videoRid[$i]['url'], PHP_URL_PATH), 1);
		
			        $videoRid[$i]['url']=$videoRid[$i]['url'];
                     $videoRid[$i]['vimeo_id']=$id;
                  $vclasssub[$i]['playlistmanagement_id']=2;
                  $videoRid[$i]['hash_id']=$videoRid[$i]['hash_id'];
                 	 $videoRid[$i]['type']=$videoRid[$i]['playlistmanagement_id'];

			  
                  $videoRid[$i]['image']=$videoRid[$i]['image'];
                  $videoRid[$i]['duration']=$videoRid[$i]['duration'];


              }
		
		}
		return $videoRid;
	}
	// get video by id 
	public function graph(Request $request,$name,$id,$playlist='')
	{
		
		if($name=="tt")
		
		{
		 $textdt=date("D F Y");
		 $list=[];
		$dt= strtotime( $textdt);
		$currdt=$dt;
		$nextmonth=strtotime($textdt."+1 month");
		$i=0;
		do 
		{
			$weekday= date("w",$currdt);
			$nextday=7-$weekday;
			$endday=abs($weekday-6);
			$startarr[$i]=$currdt;
			$endarr[$i]=strtotime(date("Y-m-d",$currdt)."+$endday day");
			$currdt=strtotime(date("Y-m-d",$endarr[$i])."+1 day");
			$startdate=date("Y-m-d",$startarr[$i]);
			$endate=date("Y-m-d",$endarr[$i]);
		
			$list[]=array(
						'weeks'=>$i+1,
						'totalcount'=>$this->GetTotalVideo($startdate,$endate),
						'viewcount'=>1,
						'sDate'=>$startdate,
						'lDate'=>$endate
						);
			//echo "Week ".($i+1). "-> start date = ". date("Y-m-d",$startarr[$i])." end date = ". date("Y-m-d",$endarr[$i])."<br>";
			 $i++;
						 
		}
		while($endarr[$i-1]<$nextmonth);
		
		
		return view('admin.graph.tt',compact('list'));
		}
		elseif($name=="qp")
		{
			//quiz performance
		/*	$textdt=date("D F Y");
		 $list=[];
		$dt= strtotime( $textdt);
		$currdt=$dt;
		$nextmonth=strtotime($textdt."+1 month");
		$i=0;
		do 
		{
			$weekday= date("w",$currdt);
			$nextday=7-$weekday;
			$endday=abs($weekday-6);
			$startarr[$i]=$currdt;
			$endarr[$i]=strtotime(date("Y-m-d",$currdt)."+$endday day");
			$currdt=strtotime(date("Y-m-d",$endarr[$i])."+1 day");
			$startdate=date("Y-m-d",$startarr[$i]);
			$endate=date("Y-m-d",$endarr[$i]);
			
			$qlists[]=array(
						'weeks'=>$i+1,
						'totalQuizcount'=>$this->GetTotalQuiz($startdate,$endate,$id,$playlist),
						'viewcount'=>1,
						'sDate'=>$startdate,
						'lDate'=>$endate
						);
			//echo "Week ".($i+1). "-> start date = ". date("Y-m-d",$startarr[$i])." end date = ". date("Y-m-d",$endarr[$i])."<br>";
			 $i++;
						 
		}
		while($endarr[$i-1]<$nextmonth);
		
		 $GetQuizList = array();

		  // foreach ( $playlistmanagement as $playlistmanagements) 
		  // {

           // $getq = $this->GetQuizL($playlistmanagements['id']);

			// if(isset($getq) and sizeof($getq) > 0){ 
            // $GetQuizList = array(
				// 'Quiz'=>$getq
            // );
			// }
			
         // } */
		 $playlistmanagement = PlaylistManagement::get()->toArray();
		
			$qlists=QuizManagement::
		    join('videosmanagement','videosmanagement.id','=','quizmanagement.videomanagement_id')
		    ->join('attemptquiz','attemptquiz.video_id','=','videosmanagement.id')
		  //  ->whereBetween('attemptquiz.created_at', [$Svidid, $endvid])
		    ->where('attemptquiz.user_id',$id)
		     ->where('videosmanagement.playlistmanagement_id',$playlist)
		 ->count();
	//	->toSql();
		 $listQP=[];
		 for($l=1;$l <= $qlists; $l++) {
		     $listQP[]=array(
		         'quiz'=>$l,
		         'number'=>0
		         );
		 }
		 
 
		
		//$qlists=$this->GetTotalQuiz($id,$playlist);
		return view('admin.graph.qp',compact('listQP','playlistmanagement'));
		}
		else {
			// quiz taken
				$textdt=date("D F Y");
		 $list=[];
		$dt= strtotime( $textdt);
		$currdt=$dt;
		$nextmonth=strtotime($textdt."+1 month");
		$i=0;
		do 
		{
			$weekday= date("w",$currdt);
			$nextday=7-$weekday;
			$endday=abs($weekday-6);
			$startarr[$i]=$currdt;
			$endarr[$i]=strtotime(date("Y-m-d",$currdt)."+$endday day");
			$currdt=strtotime(date("Y-m-d",$endarr[$i])."+1 day");
			$startdate=date("Y-m-d",$startarr[$i]);
			$endate=date("Y-m-d",$endarr[$i]);
			
			$lists[]=array(
						'weeks'=>$i+1,
						'totalQuizcount'=>$this->GetTotalQuizTaken($startdate,$endate),
						'viewcount'=>1,
						'sDate'=>$startdate,
						'lDate'=>$endate
						);
			//echo "Week ".($i+1). "-> start date = ". date("Y-m-d",$startarr[$i])." end date = ". date("Y-m-d",$endarr[$i])."<br>";
			 $i++;
						 
		}
		while($endarr[$i-1]<$nextmonth);
		
		
		return view('admin.graph.qa',compact('lists'));
		}
		// echo $name;
		// echo "<br/>";
		// echo $id;
		//die();
		
	}
	
	public function GetQuizL($playid)
	{
		$videoid = VideosManagement::where('playlistmanagement_id',$playid)->get()->toArray();
		$GetQPList = array();

		  foreach ( $videoid as $videoids) 
		  {

           $getpq = $this->GetQuizplaylsitL($videoids['id']);

			if(isset($getpq) and sizeof($getpq) > 0){ 
            $GetQPList = array(
				'Quizlist'=>$getpq
            );
			}
			
         }
	}
	public function GetQuizplaylsitL	($Qplayid)
	{
		$Quizvideoid = QuizManagement::where('videomanagement_id',$Qplayid)
		->groupBy('videomanagement_id')->get()->toArray();
		return $Quizvideoid;
	}
	public function GetTotalVideo($Svqidid,$endqid)
	{
		
		$vcount=VideosManagement::whereBetween('created_at', [$Svqidid, $endqid])
		 ->count();
		return $vcount;
	}
	public function GetTotalQuiz($id,$playList)
	{
		
		$vqcount=QuizManagement::
		    join('videosmanagement','videosmanagement.id','=','quizmanagement.videomanagement_id')
		    ->join('attemptquiz','attemptquiz.video_id','=','videosmanagement.id')
		  //  ->whereBetween('attemptquiz.created_at', [$Svidid, $endvid])
		    ->where('attemptquiz.user_id',$id)
		 ->count();
	//	->toSql();
		return $vqcount;
	}
	public function GetTotalQuizTaken($quizc,$quizcid)
	{
		
		$quiztaken=QuizManagement::whereBetween('created_at', [$quizc, $quizcid])
		->groupBy('videomanagement_id')
		 ->count();
		return $quiztaken;
	}
	public function videobyid(Request $request)
	{
		$videoid=VideosManagement::select('id','title','url','description','nextvideo_id','hash_id','image','duration')->where('id',$request->id)->first();

 	
		

		$videoid2=VideosManagement::select('classmanagement_id')->where('id',$request->id)->first();
// 		print_r($videoid2);
// 		die();
		$checkQuiz=QuizManagement::where('videomanagement_id',$request->id)->count();
		 
		$checkQuizRes=False;
		if(isset($checkQuiz) and !empty($checkQuiz)){
		    $checkQuizRes=True;
		}
		     if (strpos($videoid['url'], 'youtube') > 0) {
                    $vimeo_id=0;
                    $type=1;
                     $video_id=$this->GetLinktovideoId($videoid['url']);
			  }else{

                 $vimeo_id = (int) substr(parse_url($videoid['url'], PHP_URL_PATH), 1);


			     $type=2;
			     $video_id=0;
			  }




			if($videoid['nextvideo_id'] == NULL)
			{
			    $videoid['nextvideo_id'] = 0;
			}
	
			// $whatIWant = substr($videoid['url'], -10);
			//die();
			
			
			 

        /*$VimeoData=$this->GetLinktoImage($videoid['url'],1);
        $videoLink=max($VimeoData->pictures->sizes);*/
        
			$videoid['vimeo_id']=$vimeo_id;
			$videoid['type']=$type;
			$videoid['video_id']=$video_id;
			//$videoid['hash_id']=$this->GetLinktovideoId($videoid['url'],2);
			$videoid['hash_id']=$videoid['hash_id'];
			$videoid['hasQuiz']=$checkQuizRes;
			$videoid['image']=$videoid['image'];
			$videoid['duration']=$videoid['duration'];
	 	    $videoid['related_video']=$this->getrelatedvideo($videoid2['classmanagement_id']);
		
         if (isset($videoid) and !empty($videoid)) {
            $response['status']=TRUE;
            $response['data']=$videoid;
         
            $response['message']='matched';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
	}
	public function allvideos(Request $request)
	{
	    if($request->class_id == 0)
	    {
	        	$videoRid=VideosManagement::select('id','title','url','image')
	//	->where('classmanagement_id',$request->class_id)
		->get()->toArray();
	    }else{
		$videoRid=VideosManagement::select('id','title','url')
		->where('classmanagement_id',$request->class_id)
		->get()->toArray();
	    }
		

         if (isset($videoRid) and !empty($videoRid)) {
            $response['status']=TRUE;
            $response['data']=$videoRid;
            $response['message']='matched';

        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
	}
	public function viewprofile(Request $request)
	{
		$profile=Register::with('states')
		->with('districts')
		->with('board')->with('classes')->where('id',$request->user_id)->first();
		
		$vpro = array(
				'id'=>$profile['id'],
				'name'=>$profile['name'],
				'class'=>$profile['classes']['name'],
				'board'=>$profile['board']['name'],
				'state'=>$profile['states']['name'],
				'district'=>$profile['districts']['city'],
				'city'=>$profile['city'],
				'parent_name'=>$profile['parent_name'],
				'parent_mobile'=>$profile['parent_mobile'],
				'email'=>$profile['email'],
				'school'=>$profile['school'],
				'mobile'=>$profile['mobile_no'],
				'image'=>url('/uploads/'.$profile['image']),
			
            );
		
		if (isset($profile) and !empty($profile)) {
            $response['status']=TRUE;
            $response['data']=$vpro;
            $response['message']='matched';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
	}
	public function editprofile(Request $request)
	{
		
		 $request = $this->saveFiles($request);
		 
	 
	 if($request['name']){$editpro['name']=$request['name'];}
	 	 if($request['mobile_no']){$editpro['mobile_no']=$request['mobile_no'];}
		 	 if($request['school']){$editpro['school']=$request['school'];}
			 	 if($request['city']){$editpro['city']=$request['city'];}
				  if($request['image']){$editpro['image']=$request['image'];}
				 
				 
	 
		$profile=Register::where('id',$request->user_id)->update($editpro);
		
		if (isset($profile) and !empty($profile)) {
            $response['status']=TRUE;            
            $response['message']='updated successfully';
		//	$response['s']=$request['image'];
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
       
   
        return $this->respond($response);
	}
	
		public function pageList($name)
	{
		 if($name=='term'){
			 return view('api.terms'); 
		 }
		 if($name=='privacy'){
			 return view('api.privacy'); 
		 }
		  if($name=='license'){
			  return view('api.license');
		 }
		 
		    
	}
	 public function saveFiles(Request $request)
    {
        if (!file_exists(public_path('uploads'))) {
            mkdir(public_path('uploads'), 0777);
            mkdir(public_path('uploads/thumb'), 0777);
        }
        $newRequest = null; // Variable to hold a new request created by above array merging
        foreach ($request->all() as $key => $value) {
            if ($request->hasFile($key)) {
                if ($request->has($key . '_w') && $request->has($key . '_h')) {
                    // Check file width
                    $filename = time() . '-' . $request->file($key)->getClientOriginalName();
                    $file     = $request->file($key);
                    $image    = Image::make($file);
                    Image::make($file)->resize(50, 50)->save(public_path('uploads/thumb') . '/' . $filename);
                    $width  = $image->width();
                    $height = $image->height();
                    if ($width > $request->{$key . '_w'} && $height > $request->{$key . '_h'}) {
                        $image->resize($request->{$key . '_w'}, $request->{$key . '_h'});
                    } elseif ($width > $request->{$key . '_w'}) {
                        $image->resize($request->{$key . '_w'}, null, function ($constraint) {
                            $constraint->aspectRatio();
                        });
                    } elseif ($height > $request->{$key . '_w'}) {
                        $image->resize(null, $request->{$key . '_h'}, function ($constraint) {
                            $constraint->aspectRatio();
                        });
                    }
                    $image->save(public_path('uploads') . '/' . $filename);
                    // Determine which request's data to use further
                    $requestDataToMerge = $newRequest == null ? $request->all() : $newRequest->all();
                    // Create new request without changing the original one (prevents removal of specific metadata which disables parsing of a second file)
                    $newRequest = new Request(array_merge($requestDataToMerge, [$key => $filename]));
                } else {
                    $filename = time() . '-' . $request->file($key)->getClientOriginalName();
                    $request->file($key)->move(public_path('uploads'), $filename);
                    // Determine which request's data to use further
                    $requestDataToMerge = $newRequest == null ? $request->all() : $newRequest->all();
                    // Create new request without changing the original one (prevents removal of specific metadata which disables parsing of a second file)
                    $newRequest = new Request(array_merge($requestDataToMerge, [$key => $filename]));
                }
            }
        }

        return $newRequest == null ? $request : $newRequest;
    }
	public function viewcount(Request $request)
    {
		$data= ViewCount::where('user_id',$request['user_id'])
		->where('video_id',$request['video_id'])->get()->toArray();
		
		if(isset($data) and !empty($data))
		{
			 $update=array(
				'video_id'=>$data[0]['video_id'],
				'user_id'=>$data[0]['user_id'],
				'viewcount'=>$data[0]['viewcount']+1
			   );
		
			 ViewCount::where('user_id',$data[0]['user_id'])
		->where('video_id',$data[0]['video_id'])->update($update);
		}else{
		 $Aquiz=array(
			   'video_id'=>$request['video_id'],
				'user_id'=>$request['user_id'],
				'viewcount'=>1
			   );
			   
			 $a=ViewCount::create($Aquiz);
		}
	}
	
	public function changePassword(Request $request){
	    
	    
	    $old=$request['old'];
	    $new=$request['new'];
	    $id=$request['id'];
	    
	    
	    
	    $user = Register::where(['id' => $id])->first();
			// echo "<pre>";
			// print_r($user);
			// die();
            if (isset($user['id']) and !empty($user['id'])) {
                
                
                if(Hash::check($old, $user['password'])){
                    
                    
                    $user->password=Hash::make($new);
                    $user->save();
            $response['status']=TRUE;            
            $response['message']='Updated Successfully';
                    
                }else{
                    
                     $response['status']=FALSE;            
            $response['message']='Old Password Not Matched!!';
                }
                
              
            
            }else{
             $response['status']=FALSE;            
            $response['message']='Try Again!!';    
                
            }
	    
	       
       
   
        return $this->respond($response);
        
        
	    
	}
	public function watchlist(Request $request)
	{
	  
      $data=Watchlist::where('videomanagement_id',$request->videomanagement_id)
     	 ->whereDate('watchdate',date('Y-m-d'))
     	 ->where('user_id',$request->user_id)
    	 ->first();
    // 	 print_r($data);
	   // die();
    if(isset($data) and !empty($data))
    {
      $profile= Watchlist::where('id',$data->id)
        ->update(['watchtime'=>$request->watchtime]);
    }else{
      $profile= Watchlist::create($request->all());
    }
	  // $watchlist= Watchlist::create($request->all());
	
	   if (isset($profile) and !empty($profile)) {
            $response['status']=TRUE;            
            $response['message']='updated successfully';

           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
	   return $this->respond($response);
	   
	   
	}
	public function dsr()
	{
	    $greeting='Hello';
//SELECT user_id, COUNT(user_id) FROM notifications GROUP BY user_id HAVING COUNT(user_id) > 1



        $user= Register::select('registration.id','registration.name','registration.mobile_no','registration.parent_name')->whereNotExists(function($query)
        {
            $query->select('user_id')
                ->from('notifications')
                ->whereDate('notifications.created_at',date('Y-m-d'))
                ->where('notifications.type',1)
                ->whereRaw('notifications.user_id = registration.id');
        })->take(30)
            ->get()->toArray();



/*
	   $user=Register::select('registration.id','registration.name','registration.mobile_no','registration.parent_name')
           ->join('notifications','notifications.user_id','!=','registration.id')
           ->whereDate('notifications.created_at',date('Y-m-d'))
           ->where('notifications.type',1)
           ->inRandomOrder()
           ->take(3)
           ->get()->toArray();*/



     //   $DSRCHECK=Notifications::whereDate('created_at',date('Y-m-d'))->get()->toArray();




	    $totalQuestion=[];

	    if(isset($user) and sizeof($user) > 0){
	    	foreach($user as $users)	
		{


            Notifications::create(array(
                'user_id'=>$users['id'],
                'type'=>1,


            ));
		    
		     $qq = $this->GetWachtedvideo($users['id']);
	        $qqq = $this->GetWachtedquiz($users['id']);
		     if($qq == NULL)
		     {
		         $qq='No Video Watched';
		     }if($qqq == NULL){
		         $qqq='No Quiz Taken';
		     }
		     
			$totalQuestion=array(
			    
			  //   'name'=>$users['name'],
			     'phone'=>$users['mobile_no'],
		         'videoname'=>$qq,
		          'quizname'=>$qqq,
			    );
			   if(is_array($totalQuestion['videoname']))
			   {
			       $videowatch=implode(",\n",$totalQuestion['videoname']);
			   }else{
			       $videowatch='- NIL -';
			   }

			    if(is_array($totalQuestion['quizname']))
			   {
			       $videoquiz=implode(",\n",$totalQuestion['quizname']);
			   }else{
			       $videoquiz='- NIL -';
			   }
			 //
			 //$videoquiz=implode(",\n",$totalQuestion['quizname']);




            $studentName=$users['name']."'s";
		   $messageSender='http://priority.thesmsworld.com/api.php?username=ChetanBharat&password=149307&sender=EDUCBL&sendto=91'.$users['mobile_no'].'&message='.urlencode ('Dear '.$users['parent_name']."\n".$studentName.' Daily Progress report is:'."\n\n".'VIDEO WATCHED:'."\n\n".''. $videowatch ."\n\n".' QUIZ TAKEN:'."\n\n".''. $videoquiz.''."\n\n".'CHETAN BHARAT LEARNING' );





		 	$this->curl_get_contents($messageSender);


		  
		}

        }
	    die();
	}
	public function GetWachtedvideo($v_id)
	{
	    $Watchlist=Watchlist::where('user_id',$v_id)
     	 ->whereDate('watchdate',date('Y-m-d'))
     	 ->with('videomanagement')
     	 ->get()->toArray();
     	 $data=[];
     	 foreach($Watchlist as $Watchlists)	
		{
		    
			 $data[]=$Watchlists['videomanagement']['title'];
			  
		}	 
     	 return $data;
	}
	public function GetWachtedquiz($v_id)
	{
	     $quizdata=AttemptQuiz::where('user_id',$v_id)
     	 //->whereDate('created_at',date('Y-m-d'))
     	 ->with('quizmanagement')
     	 ->with('videomanagement')
     	 ->groupBy('video_id')
     	 ->get()->toArray();
    //  	 print_r($quizdata);
    //  	 die();
     	 $datas=[];

     	 if(isset($quizdata) and sizeof($quizdata) > 0){
     	 foreach($quizdata as $quizdatas)	
		{
		    if(isset($quizdatas['videomanagement']['title'])){
			 $datas[]=$quizdatas['videomanagement']['title'];
            }
			  
		}
         }
     	 return $datas;
	}

    public function useractivity(Request $request)
	{
	    if($request->type ==1)
	    {
	        // for watched video
	         $Watchlist=Watchlist::where('user_id',$request->user_id)
     	 ->whereDate('watchdate',$request->watchdate)
     	 ->with('videomanagement')
     	 ->groupBy('videomanagement_id')
     	 ->get()->toArray();
    //
	    }   elseif($request->type ==2){
	        
	        $Watchlist=AttemptQuiz::where('user_id',$request->user_id)
      	 ->whereDate('created_at',$request->watchdate)
     	 ->with('quizmanagement')
     	 ->with('videomanagement')
     	 ->groupBy('video_id')
     	 ->get()->toArray();
     	  // 	 print_r($Watchlist);
        //     die();
	    }else
	    {
	           $month= date("m", strtotime($request->watchdate));
       
             $year= date("Y", strtotime($request->watchdate));
	     //$from=$month."-01";
         
	   $Watchlist=Attemptquiz::whereMonth('created_at',$month)
	   ->whereYear('created_at',$year)
	   ->where('user_id',$request['user_id'])
     	 ->with('quizmanagement')
     	 ->with('videomanagement')
     	 ->groupBy('video_id')
     	 ->get()->toArray();
    //  	 print_r($vwatch);
    //  	 die();
	    }
     	 $vclassS=[];
     	 $i=1;
     	foreach ( $Watchlist as $vclassbaseds) 
		  {
    if($request->type ==1)
	    {
	        
          $subjc = $this->Getwatchvideos($vclassbaseds['videomanagement_id']);
               $subjcname = $this->getsubjectname($vclassbaseds['videomanagement_id']);
               $score=0;
	    }
	    elseif($request->type ==2)
	    {
	        $subjc = $this->Getwatchvideos($vclassbaseds['video_id']);
               $subjcname = $this->getsubjectname($vclassbaseds['video_id']);
               $score=$this->GetRankung($request['user_id'],$vclassbaseds['unique_id'],$vclassbaseds['video_id']);
	    }else
	    {
	          $subjc = $this->Getwatchvideos($vclassbaseds['video_id']);
               $subjcname = $this->getsubjectname($vclassbaseds['video_id']);  
                $score=$this->GetRankung($request['user_id'],$vclassbaseds['unique_id'],$vclassbaseds['video_id']);
	    }
			if(isset($subjc) and sizeof($subjc) > 0){ 
            $vclassS[] = array(
                'sr_no'=>$i++,
				'subjectmanagement_id'=>$subjcname['subjectmanagement']['id'],
				'name'=>$subjcname['subjectmanagement']['name'],
				'score'=>$score['rank'],
				'unique_id'=>$score['unique_id'],
				'watch_date'=>date("j-F-Y", strtotime($score['watch_date'])),
				'total_score'=>$score['totalscore'],
				'video'=>$subjc
            );
			}
			
         }
        //  print_r($vclassS);
        //      	 die();
	    
	 
	    if (isset($vclassS) and !empty($vclassS)) {
            $response['status']=TRUE;            
            $response['data']=$vclassS;

           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='no record found';
        }
        return $this->respond($response);
	}
	public function getsubjectname($vid)
	{
	    	$vclasssubject=VideosManagement::select('subjectmanagement_id')
		->with('subjectmanagement')
		->where('id',$vid)
		->first();
		return $vclasssubject;
	}
	public function Getwatchvideos($id)
	{
		$vclasssub=VideosManagement::select('id','title','url')
		//->with('subjectmanagement')
		->where('id',$id)
		->get()->toArray();
		for($i=0; $i < sizeof($vclasssub); $i++)
		{
			$vclasssub[$i]['image']=$this->GetLinktoImage($vclasssub[$i]['url']);
		}
		return $vclasssub;
	}
	public function leaderboard(Request $request)
	{
      
 
        //$watchlist=  "SELECT * FROM `attemptquiz` WHERE created_at BETWEEN "2020-01-01" AND "2020-01-16" ORDER by id DESC"
              $month= date("m", strtotime($request->ldate));
       
             $year= date("Y", strtotime($request->ldate));
	     //$from=$month."-01";
         
	   $watchlist=Attemptquiz::whereMonth('created_at',$month)
	   ->whereYear('created_at',$year)
	  ->with('users')
	   ->groupBy('user_id')
	   ->groupBy('video_id')
	   ->orderBy('id','ASC')
         ->get()->toArray();
        // print_r();
        // die();
	   $user=Register::select('id','class_id','district','school')->with('districts')->where('id',$request->user_id)->first();
	  
	    $vclassS=[];
	    	for($i=0; $i < sizeof($watchlist); $i++)
		{
		    if($watchlist[$i]['users']['class_id'] == $user['class_id'] and $watchlist[$i]['users']['district'] == $user['district'])
		    {
			$ranking=$this->GetRankung2($watchlist[$i]['user_id'],$month,$year);
		   
			 $vclassS[] = array(
	    	     	    'id'=> $watchlist[$i]['users']['id'],
    	                'name'=> $watchlist[$i]['users']['name'],
    	                 'district'=> $user['districts']['city'],
	                      'school'=>$watchlist[$i]['users']['school'],
	                      'city'=>$watchlist[$i]['users']['city'],
	                     // 'created_at'=> $watchlist[$i]['created_at'],
			            'score'=>$ranking,
			            'rank'=>1
            );
            
            	$price = array_column($vclassS, 'score');
            	array_multisort($price, SORT_DESC, $vclassS);
		    
		    }
		   for($j=0; $j < sizeof($vclassS); $j++)
		{
		    $vclassS[$j]['rank']=$j+1;
		}
		
		}
			 
// 		$vc_array_name=array();
// 		    foreach ($vclassS as $key => $row)
// 		    {
// 		        $vc_array_name[$key] = $row['score'];
		      
				   
		  
// 		    }
// 		    array_multisort($vc_array_name, SORT_DESC, $vclassS);
// 		   print_r($vc_array_name);
//           die();
	    if (isset($vclassS) and !empty($vclassS)) {
            $response['status']=TRUE;            
            $response['data']=$vclassS;

           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='no record found';
        }
        return $this->respond($response);
	}
	public function GetRankung($uid,$uni_id,$vid_id)
	{
	   // echo $uid;
	   // die();
	    $correct=0;
	    $incorrect=0;
	    $totalscore=Attemptquiz::where('user_id',$uid)
	  //  ->where('point',2)
	    ->where('unique_id',$uni_id)
	     ->where('video_id',$vid_id)
	     ->orderBy('id','ASC')
	    ->get()->count();
	    
	     $wdate=Attemptquiz::select('created_at','unique_id')->where('user_id',$uid)
	  //  ->where('point',2)
	    ->where('unique_id',$uni_id)
	     ->where('video_id',$vid_id)
	     ->orderBy('id','ASC')
	    ->first();
	   // print_r($wdate['created_at']);
	   // die();
	    $correct=Attemptquiz::where('user_id',$uid)
	    ->where('point',2)
	    ->where('unique_id',$uni_id)
	     ->where('video_id',$vid_id)
	    //->whereBetween('created_at', [$f,$t])
	     //->groupBy('video_id')
	     ->orderBy('id','ASC')
	    ->get()->count();

	    $incorrect=Attemptquiz::where('user_id',$uid)->where('point',1)
	     ->where('unique_id',$uni_id)
	     ->where('video_id',$vid_id)
	  // ->whereBetween('created_at', [$f,$t])
	  // ->groupBy('video_id')
	     ->orderBy('id','ASC')
	    ->get()->count();
	  
	
	    $rank=($correct*2)-$incorrect;
	    $rank=array(
	        'rank'=>$rank,
	        'watch_date'=>$wdate['created_at'],
	        'unique_id'=>$wdate['unique_id'],
	        'totalscore'=>$totalscore*2
	        );
	    return $rank;
	}
	public function GetRankung2($uid,$m,$y)
	{
	    $correct=0;
	    $incorrect=0;

	    $correct=Attemptquiz::where('user_id',$uid)->where('point',2)
        ->whereMonth('created_at',$m)
	   ->whereYear('created_at',$y)
	    //->whereBetween('created_at', [$f,$t])
	 //    ->groupBy('unique_id')
	       ->groupBy('video_id')
	     ->orderBy('id','ASC')
	    ->get()->count();
	   
	    $incorrect=Attemptquiz::where('user_id',$uid)->where('point',1)
	   ->whereMonth('created_at',$m)
	   ->whereYear('created_at',$y)
	  // ->whereBetween('created_at', [$f,$t])
	//   ->groupBy('unique_id')
      ->groupBy('video_id')
	     ->orderBy('id','ASC')
	    ->get()->count();

	    
	    $rank=($correct*2)-$incorrect;

        // print_r($correct);
        //  die();
	    return $rank;
	}
	 public function plans(Request $request)
    {
        $sub = Plan::select('id','name','price','validity','orignal_price','bg_color','top_color')->get()->toArray();
         if (isset($sub) and !empty($sub)) {
            $response['status']=TRUE;
            $response['data']=$sub;
            $response['message']='classes';
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
         return $this->respond($response);
    }
    public function yourplan(Request $request)
    {
        
         $Subscriptions=Subscriptions::where('user_id',$request->user_id)
         ->whereDate('end_date','>=',date('Y-m-d'))
         ->where('plan',101)
         ->first();
         
        $ipSubscriptions=Subscriptions::where('user_id',$request->user_id)
         ->whereDate('end_date','>=',date('Y-m-d'))
         ->where('plan','!=',101)
         ->get();
        
        if(isset($Subscriptions) and !empty($Subscriptions))
        {
          $currentplan[]=array(
                  'plan'=>TRUE,
    	        'start_date'=>date("d-F-Y",strtotime($Subscriptions['start_date'])),
    	        'end_date'=>date("d-F-Y",strtotime($Subscriptions['end_date'])),
    	        'plan_name'=>'Trial Version',
    	        'price'=>'Free',
	        );
        }else
        {
             $currentplan[]=array(
              'plan'=>FALSE,
               'start_date'=>"",
    	        'end_date'=>"",
    	        'plan_name'=>"",
    	        'price'=>"",
    	        );
        }
	      if(empty($ipSubscriptions))
        {   
             $plan[]=array(
              'plan'=>FALSE,
               'start_date'=>"",
    	        'end_date'=>"",
    	        'plan_name'=>"",
    	        'price'=>"",
    	        );
        }else
        {
            $plan=[];
         foreach($ipSubscriptions as $Subscription)
         {
             $plan_detail=$this->GetPlan_info($Subscription['plan']);
               $plan[]=array(
                    'plan'=>TRUE,
    	       'start_date'=>date("d-F-Y",strtotime($Subscription['start_date'])),
    	        'end_date'=>date("d-F-Y",strtotime($Subscription['end_date'])),
    	        'plan_name'=>$plan_detail['name'],
    	        'price'=>$plan_detail['price'],
    	        );
         
         }
            
        }
          if (isset($currentplan) and !empty($currentplan)) {
            $response['status']=TRUE;
            $response['current_plan']=$currentplan;
            $response['upcoming_plan']=$plan;
           
        }else{
            $response['status']=FALSE;
            $response['data']=NULL;
            $response['message']='falied';
        }
         return $this->respond($response);
         
    }
    public function GetPlan_info($p_id)
    {
         $plan=Plan::where('id',$p_id)->first();
         return $plan;
    }
    public function savepayment(Request $request)
    {
       Transactions::create($request->all());
               $Subscriptions=Subscriptions::where('user_id',$request->user_id)
         ->whereDate('end_date','>=',date('Y-m-d'))
       //  ->where('plan',101)
         ->first();
         if($request->payment_status == 'true')
         {
          $currentplan=array(
                  'plan'=>$request->plan_id,
    	        'start_date'=>$Subscriptions->end_date,
    	        'end_date'=>date("Y-m-d",strtotime($Subscriptions->end_date."+30 days")),
    	        'user_id'=>$request->user_id,
	        );
	      Subscriptions::create($currentplan);
         }
        //  print_r($currentplan);
        //  die();
             $response['status']=TRUE;
        $response['end_date']=$currentplan['end_date'];
           return $this->respond($response);
    }

    public function emails(){


        $to_name = 'parminderaquasoft@gmail.com';
        $to_email = 'parminderaquasoft@gmail.com';
        $data = array('name'=>"Ogbonna Vitalis(sender_name)", "body" => "A test mail");
        print_r($data);

$data=Mail::send('emails.mail', $data, function($message) use ($to_name, $to_email) {
    $message->to($to_email, $to_name)
        ->subject('Laravel Test Mail');
$message->from('parminderaquasoft@gmail.com','Test Mail');
});





    }
	
	
}
