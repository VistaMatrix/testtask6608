<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use App\User;

use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class Login extends Controller
{


    public function index(Request $request)
    {
        echo "hello";
        die();

    }


    public function register(Request $request){

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20|unique:users',
            'gender' => 'required|string|max:11',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:4',
        ]);

        if($validator->fails()){

            return response()->json([
                'error' => $validator->errors()->toJson(),
                'status'=>False,
            ], 400);


        }

        $user = new User([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'gender' => $request->gender,
            'role_id' => 2,
            'password' => bcrypt($request->password)
        ]);
        $user->save();


        return response()->json([
            'user_id' => $user->id,
            'message' => 'OTP Sent Please Enter!!',
            'status'=>True,
        ], 200);

/*
        if(!Auth::loginUsingId($user->id))
            return response()->json([
                'message' => 'User Not Found!!',
                'status'=>False,
            ], 401);

        $user = $request->user();

        $tokenResult = $user->createToken('InvestorMOB');
        $token = $tokenResult->token;

        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(1);

        $token->save();

        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'data' => $user,
            'status'=>True,
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString()
        ]);*/




    }


    public function verifyOtp(Request $request){

        $validator = Validator::make($request->all(), [
            'user_id' => 'required|string',
            'otp' => 'required|string|min:4',

        ]);

        if($validator->fails()){

            return response()->json([
                'error' => $validator->errors()->toJson(),
                'status'=>False,
            ], 400);


        }




        if(!Auth::loginUsingId($request->user_id))
            return response()->json([
                'message' => 'User Not Found!!',
                'status'=>False,
            ], 401);

        $user = $request->user();

        $tokenResult = $user->createToken('InvestorMOB');
        $token = $tokenResult->token;

        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(1);

        $token->save();

        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'data' => $user,
            'status'=>True,
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString()
        ]);






    }
    public function authenticate(Request $request){

        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            'remember_me' => 'boolean'
        ]);

        $credentials = $request->only('email', 'password');

        if(!Auth::attempt($credentials))
            return response()->json([
                'message' => 'User Not Found!!',
                'status'=>False,
             ], 401);

        $user = $request->user();

        $tokenResult = $user->createToken('InvestorMOB');
        $token = $tokenResult->token;

        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(1);

        $token->save();

        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'data' => $user,
            'status'=>True,
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString()
        ]);
    }

    public function logout(Request $request){

        $request->user()->token()->revoke();

        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }

    public function getAuthenticatedUser(Request $request){

        // return response()->json($request->user());
        return response()->json(['user' => auth()->user()], 200);
    }

}
