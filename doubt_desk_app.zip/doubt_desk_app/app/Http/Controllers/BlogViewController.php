<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\BlogModel;
use Auth;

class BlogViewController extends Controller
{
   public function index()
    {
        $Blogs = BlogModel::all();
       
        return view('admin.articles.index', compact('Blogs'));
    }
}
